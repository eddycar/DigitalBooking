package com.proyectointegrador.digitalbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
